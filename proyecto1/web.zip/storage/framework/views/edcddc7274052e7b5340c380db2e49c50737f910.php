<html>
<head>
<title>Mi Aplicacion - <?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
<header><h1>Logo-Menu</h1></header>
<div class="container">
<?php echo $__env->yieldContent('content'); ?>
</div>
<footer>Copyright- CBG</footer>
</body>
</html><?php /**PATH /home/vagrant/code/proyecto1/resources/views/master.blade.php ENDPATH**/ ?>