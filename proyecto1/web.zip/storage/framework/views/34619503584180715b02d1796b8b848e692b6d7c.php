<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
	
	<head>
    	<meta charset="utf-8">
		<title> </title>
		<script type="text/javascript"></script>
	</head>
 
	<body>
		<h1>Vista detalle pelicula <?php echo e($id); ?></h1>
	</body>

</html><?php /**PATH /home/vagrant/code/proyecto1/resources/views/show.blade.php ENDPATH**/ ?>