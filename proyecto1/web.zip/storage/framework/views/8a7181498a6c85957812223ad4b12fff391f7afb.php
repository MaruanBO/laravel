<?php $__env->startSection('title', 'Contacto'); ?>
<?php $__env->startSection('content'); ?>
<h1 >Contacto</h1>
<p>Mi nombre es <?php echo e($nombre); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/proyecto1/resources/views/contacto.blade.php ENDPATH**/ ?>