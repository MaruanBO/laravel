@extends('master')
@section('title', 'Contacto')
@section('content')
<h1 >Contacto</h1>
<p>Mi nombre es {{$nombre}}</p>
@endsection